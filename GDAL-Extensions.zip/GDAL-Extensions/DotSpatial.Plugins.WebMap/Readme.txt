﻿Allow to view various web maps: google, osm, yahoo, wms.
Brutile: used changeset 647001c23540 from official repo at https://brutile.codeplex.com/